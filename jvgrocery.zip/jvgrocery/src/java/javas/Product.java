package javas;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Admin
 */
public class Product {
 private int idprod; 
 private String name;
 private Double price;
 private String desc;
 private int qty;

public Product(){
    this.idprod=0;
    this.name="non defini";
    this.price=0.0;
    this.desc="non defini";
    this.qty=0;
    
} 
public Product(int idprod,String name,Double price,String desc,int qty){
    this.idprod=idprod;
    this.name=name;
    this.price=price;
    this.desc=desc;
    this.qty=qty;
}

    Product(String nomprod, String descprod, double prixprod) {
        this.name=nomprod;
        this.desc=descprod;
        this.price=prixprod;
    }
public int getId(int idprod) {
    
   return idprod;
}
public String getName(String name) {
    
   return name;
}
public void setName(String name) {
    
    this.name=name;
}
public Double getPrice(Double price) {
    
   return price;
}
public void setPrice(Double price) {
    
    this.price=price;
}
public String getDesc(String desc) {
    
   return desc;
}
public void setDesc(String desc) {
    
    this.desc=desc;
}
public int getQty(int qty) {
    
   return qty;
}
public void setName(int qty) {
    
    this.qty=qty;
}



}
