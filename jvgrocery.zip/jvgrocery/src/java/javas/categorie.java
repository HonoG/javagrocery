package javas;


import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Admin
 */
public class categorie {
    private int idcat;
    private String nomcat;
    private Product prod;
    private ArrayList<Product> listprod;
    private int prodActif;
    
  public categorie(){
      this.idcat=0;
      this.nomcat="non defini";
      this.prodActif=0;
  } 
  public categorie(ArrayList prod){
      this.listprod=prod; 
  }
  public ArrayList getProd(int index){
      return this.listprod;
  }
  public void showProduit()
  {
        Product[] tabProduit = new Product[4];
        //tabProduit[0]= getProd[1];
        
        
    
}
}
