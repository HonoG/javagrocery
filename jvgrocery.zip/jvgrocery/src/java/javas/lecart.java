package javas;

import java.util.ArrayList;
import javas.Product;
import static java.time.Instant.MAX;



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Admin
 */
public class lecart {
    


 private ArrayList<Product> listprod;
 private static final int MAX = 100;
 public lecart()
 {
     String message=" votre panier est vide";
 }
 
public ArrayList showprod(int index)
 {
     return this.listprod;
 }
 public void vider()
 {
     
     if(listprod.isEmpty())
     {
     String message=" votre panier est vide";
     }
     else
     {
         listprod.clear();
     }
 }
 
 public void addprod()
 {
 
 }
 
 
 public void  qtyInStock()
{
    for(int i=0; i< MAX; i++)
    {
        System.out.println("in qtyInStock loop\n" + listprod.get(i));
        System.out.println("getting quantity qtyInStock" + listprod.get(i));
    }
}
 
 
  public static void add(Product prod) {
        //ArrayList<String> Declaration
        ArrayList<Product> listprod= new ArrayList<Product>();
        //add method for String ArrayList
        listprod.add(prod);     
        System.out.println("Elements of ArrayList of String Type: "+listprod);
      
    }
 
}
