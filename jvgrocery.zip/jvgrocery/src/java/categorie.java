
import java.beans.Transient;
import java.util.ArrayList;
import java.util.Base64;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Admin
 */
public class categorie {
    private int idcat;
    private String nomcat;
    private Product prod;
     private byte[] photo;
    private ArrayList<Product> listprod;
    private int prodActif;
    private String base64Image;
    
  public categorie(){
      this.idcat=0;
      this.nomcat="non defini";
      this.prodActif=0;
      //probleeem
  } 
   public categorie(int id,String nomcat,int prodActif,byte[] photo){
      this.idcat=id;
      this.nomcat=nomcat;
      this.prodActif=prodActif;
      this.photo=photo;
  } 
    public categorie(int id,String nomcat,byte[] photo){
      this.idcat=id;
      this.nomcat=nomcat;
      
      this.photo=photo;
  } 
    
     public categorie(int id,String nomcat){
      this.idcat=id;
      this.nomcat=nomcat;
  } 
    
  
  public categorie(ArrayList<Product> prod){
      this.listprod=prod; 
  }
  public ArrayList<Product> getProd(int index){
      return this.listprod;
  }
  public String getCatName(String name) {
    
   return name;
}
public void setCatName(String name) {
    
    this.nomcat=name;
}
  public byte[] getCatPhoto(byte[] photo) {
    
   return photo;
}
public void setCatPhoto(byte[] photo) {
    
    this.photo=photo;
}
 public void setBase64Image(String base64Image) {
        this.base64Image = base64Image;
    }
 @Transient
public String getBase64Image() {
    base64Image = Base64.getEncoder().encodeToString(this.photo);
    return base64Image;
}

}
