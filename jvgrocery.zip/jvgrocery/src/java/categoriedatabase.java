
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Admin
 */
public class categoriedatabase implements Icategorie {
  
   String url = "jdbc:mysql://localhost:3306/javagrocery?zeroDateTimeBehavior=convertToNull";
   String user = "root";
   String pw = "";
   gatewaygrocery data = new gatewaygrocery(url,user,pw);
   
   

   /*@Override 
   public ArrayList<categorie> showCatPhotos()   
   {
       return data.showCatPhotos();
   }    */

    @Override
    public ArrayList<categorie> showCatPhotos() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}

