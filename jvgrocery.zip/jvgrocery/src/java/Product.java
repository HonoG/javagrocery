/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Admin
 */
public class Product {
 private int idprod; 
 private String name;
 private Double price;
 private String desc;
 private int qty;

public Product(){
    this.idprod=0;
    this.name="non defini";
    this.price=0.0;
    this.desc="non defini";
    this.qty=0;
    
} 
public Product(String name,Double price,String desc,int qty){
    
    this.name=name;
    this.price=price;
    this.desc=desc;
    this.qty=qty;
}
public int getId(int idprod) {
    
   return idprod;
}
public String getName() {
    
   return name;
}
public void setName(String name) {
    
    this.name=name;
}
public Double getPrice() {
    
   return price;
}
public void setPrice(Double price) {
    
    this.price=price;
}
public String getDesc() {
    
   return desc;
}
public void setDesc(String desc) {
    
    this.desc=desc;
}
public int getQty() {
    
   return qty;
}
public void setName(int qty) {
    
    this.qty=qty;
}



}
