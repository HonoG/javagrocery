
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.Base64;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Admin
 */
public class gatewaygrocery {
    
    private Connection conn;
    private PreparedStatement showAllProducts,addToCart;
    private ResultSet result;
    private String url,user,pw;
        

        
  public  gatewaygrocery(String url,String user,String pw)
           {
        
              try {
            this.url=url;
            this.user=user;
            this.pw=pw;
            
            conn = DriverManager.getConnection(this.url, this.user, this.pw);
            showAllProducts = conn.prepareStatement("select * from produit where nomcat=?;");
            
        } catch (SQLException ex) {
            Logger.getLogger(gatewaygrocery.class.getName()).log(Level.SEVERE, null, ex);
        }
       
}
   
   public ArrayList<Product> showAllProducts(String cat)
    {
        ArrayList<Product> listOfProducts = new ArrayList<Product>();
        try 
        {
            this.showAllProducts.setString(1,cat);
            result = this.showAllProducts.executeQuery();
            
            while(result.next())
            {
                listOfProducts.add(new Product(result.getString("name"),result.getDouble("prix"),result.getString("desc"),result.getInt("qty")));
            }
            
           
        }
        catch (SQLException ex)
        {
            Logger.getLogger(gatewaygrocery.class.getName()).log(Level.SEVERE, null, ex);
        }
        
         return listOfProducts;
    }
   
   
    public int addToCart(Product P)
    {
          int rowAffected = 0;     
        try 
        {
            this.addToCart.setString(1,P.getName());
            this.addToCart.setString(2,P.getDesc());
            this.addToCart.setDouble(3, P.getPrice());
            this.addToCart.setInt(4, P.getQty());
            
            rowAffected = this.addToCart.executeUpdate();
            
        }
        catch (SQLException ex)
        {
            Logger.getLogger(gatewaygrocery.class.getName()).log(Level.SEVERE, null, ex);
        }
          
        return rowAffected;
    }
      
    
    
      /* public int deletelegume(int id)
    {
        int rowAffected = 0;
         
        try 
        {
            this.deletelegume.setInt(1,id);
           rowAffected = this.deletelegume.executeUpdate();
            
        }
        catch (SQLException ex)
        {
            Logger.getLogger(gatewaylegume.class.getName()).log(Level.SEVERE, null, ex);
        }
          
        return rowAffected ;
    }
    
        public int updatelegume(clsLegume l)
    {
        int rowAffected =0;
         
        try 
        {
            this.updatelegume.setString(1,l.GetNom());
            this.updatelegume.setDouble(2,l.GetPrix());
            this.updatelegume.setString(3,l.getType());
            this.updatelegume.setInt(4,l.GetId());

           rowAffected = this.updatelegume.executeUpdate();
            
        }
        catch (SQLException ex)
        {
            Logger.getLogger(gatewaylegume.class.getName()).log(Level.SEVERE, null, ex);
        }
          
        return rowAffected ;
    }
    */
}
